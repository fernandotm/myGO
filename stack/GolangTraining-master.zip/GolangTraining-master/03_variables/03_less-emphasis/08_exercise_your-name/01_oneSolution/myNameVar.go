package main

import "fmt"

var name = "Todd"

func main() {
	fmt.Println("Hello ", name)
}
