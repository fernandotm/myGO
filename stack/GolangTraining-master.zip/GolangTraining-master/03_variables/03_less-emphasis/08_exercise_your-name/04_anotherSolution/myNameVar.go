package main

import "fmt"

func main() {
	name := `Todd` // back-ticks work like double-quotes
	fmt.Println("Hello ", name)
}
