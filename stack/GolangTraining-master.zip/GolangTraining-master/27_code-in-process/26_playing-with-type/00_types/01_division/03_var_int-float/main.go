package main

import "fmt"

func main() {
	answer := 32 / 3.74
	fmt.Println(answer)
}
