package main

import "github.com/GoesToEleven/SummerBootCamp/05_golang/02/01/07_packages/hello"

func main() {
	hello.Hello()
	hello.ByeBye()
}
